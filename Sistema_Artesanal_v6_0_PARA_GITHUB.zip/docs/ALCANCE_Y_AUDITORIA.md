# Auditoría preliminar de la versión Android v6.0

## Alcance decidido

- Equipo principal: Android, con SQLite local y flujo offline-first.
- Computadora, portal de consulta, PostgreSQL y sincronización **fuera del alcance actual**.
- Inventario únicamente de producto terminado.
- Pantalla de bienvenida y logo configurable dentro de la app.

## Pruebas ejecutadas

- 18 de 18 pruebas sobre repositorio JavaScript y SQLite real (Node 22 node:sqlite): creación de cliente, teléfono válido/inválido, monto válido/inválido, productos/fórmulas sin huevo, versión de receta, compras prorrateadas, volumen y stock, cotización, pack, factura congelada, abono/recibo, idempotencia, entrega sin duplicados, respaldo lógico y rollback.
- SQLite inicial: `integrity_check = ok` y `foreign_key_check = 0` en la copia seed.
- Sintaxis JavaScript: analizada mediante Node `new Function` para interfaz y `node --check` para módulos.
- Intento de revisión visual móvil con Chromium: **BLOQUEADO** por política del entorno que impide navegar a 127.0.0.1 y archivos locales; no se debe computar como prueba aprobada.
- Compilación de APK Android: **NO REALIZADA** porque el entorno carece de Android SDK y Gradle y no tiene acceso a repositorios de descarga. La configuración Gradle y el flujo GitHub Actions están incluidos como medios de compilación, aún sin validar.

## Requisitos desarrollados a nivel de código, pendientes de pruebas en celular

1. WebView Android que carga HTML local sin red; puente JSON SQL a SQLite nativo.
2. Formularios y navegación migrados del prototipo v5.6.
3. Base SQLite de prueba con tablas, CHECK, FK, triggers y vistas.
4. Recepciones y salidas de stock atómicas; pagos ligados a facturas; IDs únicos.
5. Guardado de PNG en carpetas por tipo y compartir vía panel Android.
6. Exportar SQLite consistente y recuperar con validación y copia previa.
7. Exportar JSON y guardar logo.
8. Impresión Android experimental.

## Pendientes y riesgos previos a lanzamiento

1. Compilar APK con Android SDK/Gradle, instalar en Android 14-16, verificar apertura y esquema SQLite nativo.
2. Ejecutar ciclo real completo en el teléfono, incluyendo proceso offline y persistencia después de reiniciar.
3. Validar selector de archivos, importación/restauración segura y compartición WhatsApp; probar impresión Android.
4. Incorporar cifrado de DB/backups, protección por PIN/biometría y gestión de acceso.
5. Mejorar costo exacto por lote asignado a factura/entrega y márgenes históricos.
6. Ajustar ergonomía de captura de múltiples ingredientes, packs y producción grande; probar tamaños y teclado real.
7. Control sanitario de lotes, mermas/devoluciones y requisitos dominicanos de comercialización.
8. Prueba de restauración ante cierre inesperado y fallos de escritura.

**Conclusión:** prototipo móvil fuente creado y con pruebas lógicas aprobadas. **No puede declararse versión Android funcional instalada ni 95% del sistema móvil auditado** hasta compilar y probar en teléfono físico. Se mantiene desarrollo solo Android.
