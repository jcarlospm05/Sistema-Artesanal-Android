PRAGMA foreign_keys=ON;
PRAGMA journal_mode=WAL;

CREATE TABLE IF NOT EXISTS settings (
 key TEXT PRIMARY KEY NOT NULL, value TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
) STRICT;
CREATE TABLE IF NOT EXISTS families (
 id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE CHECK(length(trim(name)) BETWEEN 2 AND 80), active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
) STRICT;
CREATE TABLE IF NOT EXISTS products (
 id TEXT PRIMARY KEY, family_id TEXT NOT NULL REFERENCES families(id) ON DELETE RESTRICT,
 name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 2 AND 100), description TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
 UNIQUE(family_id,name)
) STRICT;
CREATE TABLE IF NOT EXISTS variants (
 id TEXT PRIMARY KEY, product_id TEXT NOT NULL REFERENCES products(id) ON DELETE RESTRICT,
 name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 2 AND 100), alcohol INTEGER NOT NULL DEFAULT 0 CHECK(alcohol IN (0,1)),
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)), UNIQUE(product_id,name)
) STRICT;
CREATE TABLE IF NOT EXISTS ingredients (
 id TEXT PRIMARY KEY, name TEXT NOT NULL COLLATE NOCASE UNIQUE CHECK(length(trim(name))>=2), base_unit TEXT NOT NULL CHECK(base_unit IN ('g','ml','unidad')), allergen TEXT NOT NULL DEFAULT ''
) STRICT;
CREATE TABLE IF NOT EXISTS recipe_versions (
 id TEXT PRIMARY KEY, variant_id TEXT NOT NULL REFERENCES variants(id) ON DELETE RESTRICT,
 version_no INTEGER NOT NULL CHECK(version_no>=1), title TEXT NOT NULL, yield_ml INTEGER NOT NULL CHECK(yield_ml>0),
 process_type TEXT NOT NULL DEFAULT 'mezcla' CHECK(process_type IN ('mezcla','coccion','infusion','maceracion','fermentacion','otro')),
 instructions TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'borrador' CHECK(status IN ('borrador','aprobada','archivada')),
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(variant_id,version_no)
) STRICT;
CREATE TABLE IF NOT EXISTS recipe_lines (
 id TEXT PRIMARY KEY, recipe_id TEXT NOT NULL REFERENCES recipe_versions(id) ON DELETE CASCADE,
 ingredient_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
 quantity REAL NOT NULL CHECK(quantity>0), unit TEXT NOT NULL CHECK(unit IN ('g','ml','unidad')),
 estimated_cost_cents INTEGER NOT NULL DEFAULT 0 CHECK(estimated_cost_cents>=0),
 UNIQUE(recipe_id,ingredient_id)
) STRICT;
CREATE TABLE IF NOT EXISTS packaging_packs (
 id TEXT PRIMARY KEY, name TEXT NOT NULL UNIQUE CHECK(length(trim(name))>=2), description TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
) STRICT;
CREATE TABLE IF NOT EXISTS pack_lines (
 id TEXT PRIMARY KEY, pack_id TEXT NOT NULL REFERENCES packaging_packs(id) ON DELETE CASCADE,
 label TEXT NOT NULL CHECK(length(trim(label))>=2), quantity REAL NOT NULL CHECK(quantity>0), unit_cost_cents INTEGER NOT NULL CHECK(unit_cost_cents>=0),
 scope TEXT NOT NULL CHECK(scope IN ('botella','pack','pedido','lote'))
) STRICT;
CREATE TABLE IF NOT EXISTS skus (
 id TEXT PRIMARY KEY, variant_id TEXT NOT NULL REFERENCES variants(id) ON DELETE RESTRICT,
 size_ml INTEGER NOT NULL CHECK(size_ml>0 AND size_ml<=10000), packaging_id TEXT REFERENCES packaging_packs(id) ON DELETE RESTRICT,
 title TEXT NOT NULL CHECK(length(trim(title))>=2), bottle_cost_cents INTEGER NOT NULL DEFAULT 0 CHECK(bottle_cost_cents>=0),
 label_cost_cents INTEGER NOT NULL DEFAULT 2500 CHECK(label_cost_cents>=0),
 price_cents INTEGER NOT NULL DEFAULT 0 CHECK(price_cents>=0), active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
 UNIQUE(variant_id,size_ml,packaging_id)
) STRICT;
CREATE TABLE IF NOT EXISTS clients (
 id TEXT PRIMARY KEY, name TEXT NOT NULL CHECK(length(trim(name)) BETWEEN 2 AND 120),
 phone TEXT NOT NULL CHECK(length(phone)=10 AND phone NOT GLOB '*[^0-9]*'),
 email TEXT CHECK(email IS NULL OR email='' OR (instr(email,'@')>1 AND instr(email,'.')>1)),
 address TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1))
) STRICT;
CREATE INDEX IF NOT EXISTS ix_clients_phone ON clients(phone);
CREATE TABLE IF NOT EXISTS purchases (
 id TEXT PRIMARY KEY, purchased_at TEXT NOT NULL CHECK(length(purchased_at)>=10), merchant TEXT NOT NULL CHECK(length(trim(merchant))>=2),
 receipt_ref TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
) STRICT;
CREATE TABLE IF NOT EXISTS purchase_lines (
 id TEXT PRIMARY KEY, purchase_id TEXT NOT NULL REFERENCES purchases(id) ON DELETE RESTRICT,
 ingredient_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
 purchased_qty REAL NOT NULL CHECK(purchased_qty>0), unit TEXT NOT NULL CHECK(unit IN ('g','ml','unidad')),
 total_cost_cents INTEGER NOT NULL CHECK(total_cost_cents>=0)
) STRICT;
CREATE TABLE IF NOT EXISTS batches (
 id TEXT PRIMARY KEY, batch_number TEXT NOT NULL UNIQUE CHECK(length(trim(batch_number))>=4),
 variant_id TEXT NOT NULL REFERENCES variants(id) ON DELETE RESTRICT,
 recipe_id TEXT NOT NULL REFERENCES recipe_versions(id) ON DELETE RESTRICT,
 source TEXT NOT NULL CHECK(source IN ('compras','calculadora')), produced_at TEXT NOT NULL,
 refrigerated_at TEXT, expected_ml INTEGER NOT NULL CHECK(expected_ml>=0), actual_ml INTEGER NOT NULL CHECK(actual_ml>=0),
 status TEXT NOT NULL DEFAULT 'borrador' CHECK(status IN ('borrador','en_proceso','retenido','disponible','agotado','descartado')),
 extra_cost_cents INTEGER NOT NULL DEFAULT 0 CHECK(extra_cost_cents>=0),
 notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
) STRICT;
CREATE TABLE IF NOT EXISTS batch_consumptions (
 id TEXT PRIMARY KEY, batch_id TEXT NOT NULL REFERENCES batches(id) ON DELETE RESTRICT,
 ingredient_id TEXT NOT NULL REFERENCES ingredients(id) ON DELETE RESTRICT,
 purchase_line_id TEXT REFERENCES purchase_lines(id) ON DELETE RESTRICT,
 qty REAL NOT NULL CHECK(qty>0), unit TEXT NOT NULL CHECK(unit IN ('g','ml','unidad')),
 actual_cost_cents INTEGER NOT NULL CHECK(actual_cost_cents>=0)
) STRICT;
CREATE TABLE IF NOT EXISTS batch_outputs (
 id TEXT PRIMARY KEY, batch_id TEXT NOT NULL REFERENCES batches(id) ON DELETE RESTRICT,
 sku_id TEXT NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
 bottles INTEGER NOT NULL CHECK(bottles>0), packaging_cost_cents INTEGER NOT NULL DEFAULT 0 CHECK(packaging_cost_cents>=0),
 UNIQUE(batch_id,sku_id)
) STRICT;
CREATE TABLE IF NOT EXISTS stock_movements (
 id TEXT PRIMARY KEY, batch_output_id TEXT NOT NULL REFERENCES batch_outputs(id) ON DELETE RESTRICT,
 kind TEXT NOT NULL CHECK(kind IN ('produccion','entrega','merma','devolucion','ajuste')),
 delta_bottles INTEGER NOT NULL CHECK(delta_bottles<>0),
 delivery_line_id TEXT UNIQUE REFERENCES delivery_lines(id) ON DELETE RESTRICT, reference TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
) STRICT;
CREATE INDEX IF NOT EXISTS ix_stock_output ON stock_movements(batch_output_id);
CREATE TABLE IF NOT EXISTS quotes (
 id TEXT PRIMARY KEY, number TEXT NOT NULL UNIQUE, client_id TEXT NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
 issued_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, valid_until TEXT, mode TEXT NOT NULL DEFAULT 'unidad' CHECK(mode IN ('unidad','docena','regalo','evento')),
 status TEXT NOT NULL DEFAULT 'borrador' CHECK(status IN ('borrador','emitida','aceptada','rechazada','vencida')),
 notes TEXT NOT NULL DEFAULT '', discount_cents INTEGER NOT NULL DEFAULT 0 CHECK(discount_cents>=0),
 shipping_cents INTEGER NOT NULL DEFAULT 0 CHECK(shipping_cents>=0)
) STRICT;
CREATE TABLE IF NOT EXISTS quote_lines (
 id TEXT PRIMARY KEY, quote_id TEXT NOT NULL REFERENCES quotes(id) ON DELETE CASCADE, sku_id TEXT NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
 description TEXT NOT NULL, qty INTEGER NOT NULL CHECK(qty>0), unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents>=0),
 unit_cost_snapshot_cents INTEGER NOT NULL DEFAULT 0 CHECK(unit_cost_snapshot_cents>=0),
 line_total_cents INTEGER GENERATED ALWAYS AS (qty*unit_price_cents) STORED
) STRICT;
CREATE TABLE IF NOT EXISTS quote_charges (
 id TEXT PRIMARY KEY, quote_id TEXT NOT NULL REFERENCES quotes(id) ON DELETE CASCADE,
 pack_id TEXT REFERENCES packaging_packs(id) ON DELETE RESTRICT,
 description TEXT NOT NULL, qty INTEGER NOT NULL CHECK(qty>0),
 unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents>=0), unit_cost_snapshot_cents INTEGER NOT NULL DEFAULT 0 CHECK(unit_cost_snapshot_cents>=0),
 line_total_cents INTEGER GENERATED ALWAYS AS (qty*unit_price_cents) STORED
) STRICT;
CREATE TABLE IF NOT EXISTS invoices (
 id TEXT PRIMARY KEY, number TEXT NOT NULL UNIQUE, quote_id TEXT UNIQUE REFERENCES quotes(id) ON DELETE RESTRICT,
 client_id TEXT NOT NULL REFERENCES clients(id) ON DELETE RESTRICT,
 issued_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, status TEXT NOT NULL DEFAULT 'emitida' CHECK(status IN ('emitida','anulada')),
 notes TEXT NOT NULL DEFAULT '', discount_cents INTEGER NOT NULL DEFAULT 0 CHECK(discount_cents>=0),
 shipping_cents INTEGER NOT NULL DEFAULT 0 CHECK(shipping_cents>=0)
) STRICT;
CREATE TABLE IF NOT EXISTS invoice_lines (
 id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT, sku_id TEXT NOT NULL REFERENCES skus(id) ON DELETE RESTRICT,
 description TEXT NOT NULL, qty INTEGER NOT NULL CHECK(qty>0), unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents>=0),
 unit_cost_snapshot_cents INTEGER NOT NULL DEFAULT 0 CHECK(unit_cost_snapshot_cents>=0),
 line_total_cents INTEGER GENERATED ALWAYS AS (qty*unit_price_cents) STORED
) STRICT;
CREATE TABLE IF NOT EXISTS invoice_charges (
 id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
 pack_id TEXT REFERENCES packaging_packs(id) ON DELETE RESTRICT,
 description TEXT NOT NULL, qty INTEGER NOT NULL CHECK(qty>0),
 unit_price_cents INTEGER NOT NULL CHECK(unit_price_cents>=0), unit_cost_snapshot_cents INTEGER NOT NULL DEFAULT 0 CHECK(unit_cost_snapshot_cents>=0),
 line_total_cents INTEGER GENERATED ALWAYS AS (qty*unit_price_cents) STORED
) STRICT;
CREATE TABLE IF NOT EXISTS payments (
 id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
 amount_cents INTEGER NOT NULL CHECK(amount_cents>0), method TEXT NOT NULL CHECK(method IN ('efectivo','transferencia','tarjeta','otro')),
 reference TEXT NOT NULL DEFAULT '', paid_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 idempotency_key TEXT NOT NULL UNIQUE
) STRICT;
CREATE TABLE IF NOT EXISTS receipts (
 id TEXT PRIMARY KEY, number TEXT NOT NULL UNIQUE,
 payment_id TEXT NOT NULL UNIQUE REFERENCES payments(id) ON DELETE RESTRICT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 document_path TEXT NOT NULL DEFAULT ''
) STRICT;
CREATE TABLE IF NOT EXISTS deliveries (
 id TEXT PRIMARY KEY, invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
 delivered_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, notes TEXT NOT NULL DEFAULT '', idempotency_key TEXT NOT NULL UNIQUE
) STRICT;
CREATE TABLE IF NOT EXISTS delivery_lines (
 id TEXT PRIMARY KEY, delivery_id TEXT NOT NULL REFERENCES deliveries(id) ON DELETE RESTRICT,
 invoice_line_id TEXT NOT NULL REFERENCES invoice_lines(id) ON DELETE RESTRICT,
 batch_output_id TEXT NOT NULL REFERENCES batch_outputs(id) ON DELETE RESTRICT,
 qty INTEGER NOT NULL CHECK(qty>0)
) STRICT;
CREATE TABLE IF NOT EXISTS documents (
 id TEXT PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('cotizacion','factura','recibo')),
 record_id TEXT NOT NULL, filename TEXT NOT NULL, format TEXT NOT NULL CHECK(format IN ('png','pdf')),
 sha256 TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
) STRICT;
CREATE TABLE IF NOT EXISTS audit_log (
 id TEXT PRIMARY KEY, entity TEXT NOT NULL, entity_id TEXT NOT NULL, action TEXT NOT NULL, payload_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
) STRICT;
CREATE TABLE IF NOT EXISTS sync_outbox (
 id TEXT PRIMARY KEY, entity TEXT NOT NULL, entity_id TEXT NOT NULL, op TEXT NOT NULL,
 payload_json TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 synced_at TEXT, attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts>=0)
) STRICT;
CREATE TABLE IF NOT EXISTS sync_state (
 key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
) STRICT;

-- Integridad transaccional: recepcionar producción agrega unidades al movimiento, no duplicar.
CREATE TRIGGER IF NOT EXISTS trg_output_validate BEFORE INSERT ON batch_outputs
BEGIN
 SELECT CASE WHEN (SELECT status FROM batches WHERE id=NEW.batch_id) NOT IN ('disponible','en_proceso') THEN RAISE(ABORT,'Lote no habilitado para envasar') END;
 SELECT CASE WHEN (SELECT variant_id FROM skus WHERE id=NEW.sku_id)<>(SELECT variant_id FROM batches WHERE id=NEW.batch_id) THEN RAISE(ABORT,'SKU corresponde a otra variante') END;
 SELECT CASE WHEN ((SELECT IFNULL(SUM(o.bottles*s.size_ml),0) FROM batch_outputs o JOIN skus s ON s.id=o.sku_id WHERE o.batch_id=NEW.batch_id)+NEW.bottles*(SELECT size_ml FROM skus WHERE id=NEW.sku_id))>(SELECT actual_ml FROM batches WHERE id=NEW.batch_id) THEN RAISE(ABORT,'Botellas superan volumen real del lote') END;
END;
CREATE TRIGGER IF NOT EXISTS trg_output_stock AFTER INSERT ON batch_outputs
BEGIN
 INSERT INTO stock_movements(id,batch_output_id,kind,delta_bottles,reference) VALUES ('STK-'||NEW.id,NEW.id,'produccion',NEW.bottles,'AUTO:'||NEW.batch_id);
END;
CREATE TRIGGER IF NOT EXISTS trg_move_balance BEFORE INSERT ON stock_movements
WHEN NEW.delta_bottles<0
BEGIN
 SELECT CASE WHEN (SELECT IFNULL(SUM(delta_bottles),0) FROM stock_movements WHERE batch_output_id=NEW.batch_output_id)+NEW.delta_bottles<0 THEN RAISE(ABORT,'Inventario insuficiente') END;
END;
CREATE TRIGGER IF NOT EXISTS trg_payment_limit BEFORE INSERT ON payments
BEGIN
 SELECT CASE WHEN (SELECT status FROM invoices WHERE id=NEW.invoice_id)='anulada' THEN RAISE(ABORT,'No se admite pago de factura anulada') END;
 SELECT CASE WHEN (SELECT IFNULL(SUM(amount_cents),0) FROM payments WHERE invoice_id=NEW.invoice_id)+NEW.amount_cents > (
  SELECT IFNULL((SELECT SUM(line_total_cents) FROM invoice_lines WHERE invoice_id=NEW.invoice_id),0)+IFNULL((SELECT SUM(line_total_cents) FROM invoice_charges WHERE invoice_id=NEW.invoice_id),0)+shipping_cents-discount_cents FROM invoices WHERE id=NEW.invoice_id
 ) THEN RAISE(ABORT,'Pago excede saldo facturado') END;
END;
CREATE TRIGGER IF NOT EXISTS trg_delivery_validate BEFORE INSERT ON delivery_lines
BEGIN
 SELECT CASE WHEN (SELECT status FROM invoices WHERE id=(SELECT invoice_id FROM deliveries WHERE id=NEW.delivery_id))='anulada' THEN RAISE(ABORT,'No entregar factura anulada') END;
 SELECT CASE WHEN (SELECT invoice_id FROM invoice_lines WHERE id=NEW.invoice_line_id)<>(SELECT invoice_id FROM deliveries WHERE id=NEW.delivery_id) THEN RAISE(ABORT,'Linea no pertenece a factura') END;
 SELECT CASE WHEN (SELECT sku_id FROM invoice_lines WHERE id=NEW.invoice_line_id)<>(SELECT sku_id FROM batch_outputs WHERE id=NEW.batch_output_id) THEN RAISE(ABORT,'El SKU entregado no coincide') END;
 SELECT CASE WHEN (SELECT status FROM batches WHERE id=(SELECT batch_id FROM batch_outputs WHERE id=NEW.batch_output_id))<>'disponible' THEN RAISE(ABORT,'Lote no disponible') END;
 SELECT CASE WHEN (SELECT IFNULL(SUM(qty),0) FROM delivery_lines WHERE invoice_line_id=NEW.invoice_line_id)+NEW.qty > (SELECT qty FROM invoice_lines WHERE id=NEW.invoice_line_id) THEN RAISE(ABORT,'Entrega excede lo facturado') END;
 SELECT CASE WHEN (SELECT IFNULL(SUM(delta_bottles),0) FROM stock_movements WHERE batch_output_id=NEW.batch_output_id)<NEW.qty THEN RAISE(ABORT,'Existencia insuficiente para entregar') END;
END;
CREATE TRIGGER IF NOT EXISTS trg_delivery_stock AFTER INSERT ON delivery_lines
BEGIN
 INSERT INTO stock_movements(id,batch_output_id,kind,delta_bottles,delivery_line_id,reference)
 VALUES ('STK-'||NEW.id,NEW.batch_output_id,'entrega',-NEW.qty,NEW.id,NEW.delivery_id);
END;
CREATE VIEW IF NOT EXISTS v_stock AS
 SELECT o.id AS output_id,o.batch_id,b.batch_number,o.sku_id,s.title,s.size_ml,v.name AS variant,p.name AS product,
 o.bottles produced, IFNULL(SUM(sm.delta_bottles),0) available,b.status AS batch_status
 FROM batch_outputs o JOIN batches b ON b.id=o.batch_id JOIN skus s ON s.id=o.sku_id JOIN variants v ON v.id=s.variant_id JOIN products p ON p.id=v.product_id
 LEFT JOIN stock_movements sm ON sm.batch_output_id=o.id GROUP BY o.id;
CREATE VIEW IF NOT EXISTS v_invoice_balances AS
 SELECT i.id,i.number,i.client_id,i.issued_at,i.status,
 IFNULL((SELECT SUM(line_total_cents) FROM invoice_lines WHERE invoice_id=i.id),0)+IFNULL((SELECT SUM(line_total_cents) FROM invoice_charges WHERE invoice_id=i.id),0)+i.shipping_cents-i.discount_cents AS total_cents,
 IFNULL((SELECT SUM(amount_cents) FROM payments WHERE invoice_id=i.id),0) paid_cents,
 IFNULL((SELECT SUM(line_total_cents) FROM invoice_lines WHERE invoice_id=i.id),0)+IFNULL((SELECT SUM(line_total_cents) FROM invoice_charges WHERE invoice_id=i.id),0)+i.shipping_cents-i.discount_cents-IFNULL((SELECT SUM(amount_cents) FROM payments WHERE invoice_id=i.id),0) balance_cents
 FROM invoices i;
CREATE VIEW IF NOT EXISTS v_batch_costs AS
 SELECT b.id,b.batch_number,b.actual_ml,b.extra_cost_cents,
 IFNULL((SELECT SUM(actual_cost_cents) FROM batch_consumptions WHERE batch_id=b.id),0) ingredient_cents,
 IFNULL((SELECT SUM(o.bottles*(s.bottle_cost_cents+s.label_cost_cents)+o.packaging_cost_cents) FROM batch_outputs o JOIN skus s ON s.id=o.sku_id WHERE o.batch_id=b.id),0) packaging_cents,
 b.extra_cost_cents+IFNULL((SELECT SUM(actual_cost_cents) FROM batch_consumptions WHERE batch_id=b.id),0)+IFNULL((SELECT SUM(o.bottles*(s.bottle_cost_cents+s.label_cost_cents)+o.packaging_cost_cents) FROM batch_outputs o JOIN skus s ON s.id=o.sku_id WHERE o.batch_id=b.id),0) total_cents
 FROM batches b;
