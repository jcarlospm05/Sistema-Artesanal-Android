# Formularios, navegación y usabilidad — v5.6

**Estado:** especificación implementada parcialmente en un prototipo web de SQLite para validar arquitectura y formularios; no constituye el APK Android final ni el servidor sincronizado. El sistema multiproducto utiliza el nombre de trabajo **Fórmula & Lote**. Se mantiene separada la marca comercial de las bebidas.

## Pantalla inicial y marca

- **Bienvenida / splash** con área central para el logotipo, nombre comercial y botón **Entrar al sistema**. El ejemplo usa un monograma provisional `FL` que se sustituye al cargar un logo.
- **Área de logotipo interna** permanente en el encabezado lateral/superior, más vista previa y archivo PNG/JPEG en Configuración. Límite para prueba: 200 KB; almacenamiento de logo como data URL en `settings`.
- Menú adaptable: navegación horizontal desplazable en celular y barra lateral en escritorio. El nombre de página, subtítulo y modo de acceso se muestran en la cabecera. Alertas de error/éxito explican el motivo del rechazo.
- Modo **consulta** sin llave para PC. En esta maqueta se pueden descargar borradores de cotización/factura sin registrarlos; los registros oficiales requieren llave temporal de pruebas del servidor.

## 1. Dashboard

| Elemento | Origen | Cálculo | Acción |
|---|---|---|---|
| Ventas facturadas | `v_invoice_balances` | Suma de `total_cents` excluyendo anuladas | Solo lectura |
| Dinero cobrado | `payments` | SUM(`amount_cents`) | Solo lectura |
| Cuentas por cobrar | `v_invoice_balances` | SUM(`balance_cents`) | Solo lectura |
| Botellas disponibles | `v_stock` | SUM(disponible), solo lotes disponibles | Solo lectura |
| Registros | clients, batches, products | COUNT | Solo lectura |

**Usabilidad:** todas las tarjetas tienen unidad explícita (RD$ o botellas); no mostrar facturado como si fuera dinero cobrado.

## 2. Productos y fórmulas

**Formulario «Nuevo producto / nueva variante».**

| Campo visible | Tabla.campo | Requerido | Regla/ayuda |
|---|---|---|---|
| Producto existente | `variants.product_id` | Opcional | Si se elige, crea variante sin duplicar el producto |
| Familia | `products.family_id` | Sí si es producto nuevo | Lista predefinida; o nueva familia |
| Nueva familia | `families.name` | Solo si se crea | 2–80 caracteres; único |
| Nombre de producto nuevo | `products.name` | Sí si es nuevo | 2–100 caracteres |
| Nombre variante | `variants.name` | Sí | Ej.: sin huevo, con ron, café sin alcohol |
| Incluye alcohol | `variants.alcohol` | Sí (sí/no) | No modifica automáticamente ingredientes |
| Nombre de receta | `recipe_versions.title` | Sí | Texto, versión 1 al crear variante |
| Rendimiento teórico | `recipe_versions.yield_ml` | Sí | Entero positivo en ml |
| Tipo de proceso | `recipe_versions.process_type` | Sí | Mezcla/cocción/infusión/maceración/fermentación/otro |
| Ingrediente / cantidad / unidad / costo | `recipe_lines.*` | Al crear fórmula completa | Ingredientes opcionales por producto, sin forzar huevo, leche ni ron |
| Tamaño, costo envase, etiqueta, precio venta | `skus.*` | Al menos una presentación | 200/350/750 ml en UI actual; DB admite nuevos tamaños |

**Formulario «Nueva versión de fórmula».** Variante, nombre, proceso, rendimiento, ingredientes y costos obligatorios según cada línea. Incrementa versión; nunca altera una fórmula ligada a un lote histórico. El próximo incremento de UX debe permitir **duplicar ingredientes de versión anterior** y editar en lugar de teclear de nuevo.

## 3. Compras, calculadora y producción

Dos rutas de inicio (selector **Origen**): `compras` o `calculadora`. Ambas escriben `batches`, `batch_consumptions`, `batch_outputs` y los movimientos automáticos correspondientes.

| Campo | Tabla | Obligatorio | Validación |
|---|---|---|---|
| Producto y variante | `batches.variant_id` | Sí | Debe existir |
| Versión fórmula | `batches.recipe_id` | Sí | Debe pertenecer a esa variante |
| Origen | `batches.source` | Sí | `compras` o `calculadora` |
| Comercio | `purchases.merchant` | Solo origen compras | Texto con ≥2 caracteres |
| Fecha compra | `purchases.purchased_at` | Solo origen compras | Fecha |
| Elaborado | `batches.produced_at` | Sí | Fecha/hora |
| Refrigerado | `batches.refrigerated_at` | Opcional según proceso | Fecha/hora, debe registrarse cuando aplique |
| Rendimiento teórico | `batches.expected_ml` | Sí | Entero no negativo |
| Volumen real | `batches.actual_ml` | Sí | Entero positivo; determina tope de envases |
| Cantidad comprada/consumida | `purchase_lines`, `batch_consumptions` | Sí por ingrediente | Consumo ≤ compra de esa línea; unidades compatibles |
| Total pagado por compra | `purchase_lines.total_cost_cents` | En ruta compras | RD$ con 2 decimales máximo |
| Costo usado | `batch_consumptions.actual_cost_cents` | Sí | Compra fraccionada: precio × usado/comprado |
| Envases finales | `batch_outputs` | Sí | Enteros; Σ(botellas × tamaño) ≤ volumen real |
| Otros gastos | `batches.extra_cost_cents` | No | RD$ ≥ 0 |

**Vista previa calculada:** costo estimado de insumos realmente utilizados, mililitros envasados y sobrantes; debe indicar error si se excede el rendimiento. **Aún pendiente:** editor completo de escalado automático de fórmulas y estados de control sanitario en el formulario.

## 4. Inventario terminado

Vista sin formulario de materias primas: lote, producto, variante, presentación, unidades producidas, disponibles y estado. Existencias calculadas de movimientos, no de contadores manuales. Las entregas descuentan una sola vez. Se requiere diseño posterior de una pantalla de merma/devolución controlada con motivo y autorización.

## 5. Clientes

| Campo | Requerido | Formato | Motivo |
|---|---|---|---|
| Nombre | Sí | 2–120 caracteres | Identificación en documentos |
| Celular | **Sí** | **10 dígitos ASCII, sin espacios ni guiones** | Contacto/WhatsApp |
| Correo | No | Formato básico con @ y punto | Recibos digitales |
| Dirección | No | Texto | Delivery |
| Notas | No | Texto | Seguimiento posventa |

Ejemplos: `8095551234` ✓; `809-555-1234` ✗; `809 5551234` ✗; `809555123` ✗. Se valida tanto en HTML como en Python y SQLite. **Pendiente:** búsqueda, edición y protección avanzada contra clientes duplicados.

## 6. Cotizaciones

Campos: cliente (sí), modalidad (unidad/docena/regalo/evento), líneas dinámicas (SKU, cantidad entera >0, precio RD$ >0), descuento RD$, envío RD$, pack opcional, cantidad de packs y precio del pack. Para cada línea se almacena una instantánea de descripción/precio. Total calculado = Σ líneas + Σ packs + envío − descuento. No admite total negativo. Botón **Guardar cotización** con llave, o **Preparar borrador JSON** en modo PC.

## 7. Facturación, cobros y recibos

**Facturación directa:** cliente, productos, cantidades, precios, descuento, envío, pack opcional. **Conversión:** desde cotización preservando importes y cargos; una cotización no puede convertirse dos veces. Estado comercial: emitida/anulada; estado financiero se deriva del saldo (pendiente, parcial, pagada). Cada **pago** requiere factura, importe >0, método (efectivo/transferencia/tarjeta/otro) e identificador de idempotencia; si supera saldo se rechaza. Cada pago genera recibo único. **Entrega** elige automáticamente lotes con stock disponible (primero los más antiguos) y descuenta una sola vez mediante transacción.

**Documento:** cotización, factura o recibo imprimible; PNG descargable mediante Canvas; compartir utilizando menú nativo cuando el navegador lo permite. En el APK final la carpeta de soportes necesitará APIs de almacenamiento Android.

## 8. Empaques

Nombre de pack (sí), descripción opcional, materiales repetibles: artículo (sí), cantidad >0, costo RD$ ≥0, ámbito por botella/pack/pedido/lote. Packs registrados se pueden asignar a cotizaciones y facturas, preservando importe y costo histórico. **Pendiente:** costeo automático integral por modalidad y edición posterior del pack.

## 9. Documentos y reportes

Acceso a facturas/cotizaciones/recibos; vista imprimible y PNG. Dashboard financiero con facturado, cobrado y por cobrar. Exportación por carpeta y subida automática a nube quedan pendientes del contenedor Android y permisos asociados.

## 10. Configuración, respaldo y seguridad

Nombre comercial obligatorio, logo PNG/JPEG opcional. Llave temporal de escritura de desarrollo (no login definitivo). Respaldo íntegro SQLite mediante API `sqlite3.Connection.backup`; exportación lógica JSON. **No existe todavía importación/restauración por UI** ni sincronización real con PostgreSQL. No se debe instalar abierto a Internet.

## Reglas transversales de usabilidad

1. Marcar con `*` todos los campos obligatorios; validarlos antes de guardar y devolver mensaje específico desde SQLite/API.
2. **No aceptar letras, RD$, comas, signos negativos ni más de dos decimales en campos monetarios.** En BD guardar enteros de centavos, jamás cadenas con símbolo.
3. Cantidades físicas válidas con unidad; no mezclar gramos, mililitros, latas y unidades sin factor de conversión.
4. No generar movimientos de stock al cotizar ni facturar; solo al terminar producción/confirmar entrega o merma autorizada.
5. Costos y precios históricos quedan ligados a lote/documento; editar catálogo no cambia facturas antiguas.
6. En PC sin llave: solo consulta y preparación de borradores; ningún movimiento oficial.
7. Fecha y control sanitario son campos **informativos de trazabilidad**; la vida útil comercial requiere validación externa.
