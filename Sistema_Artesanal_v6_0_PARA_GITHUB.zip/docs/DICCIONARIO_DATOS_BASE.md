# Diccionario de datos — v5.6

Base real: SQLite 3, con `PRAGMA foreign_keys=ON`, 31 tablas y 3 vistas.
Importes: enteros **en centavos**; en formularios el usuario escribe RD$ en un campo numérico validado, nunca texto con símbolo.
Datos históricos: las facturas y cotizaciones conservan `unit_price_cents`; el catálogo puede cambiar después.

## audit_log — Auditoría

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `entity` | `TEXT` | Sí |  |  |
| `entity_id` | `TEXT` | Sí |  |  |
| `action` | `TEXT` | Sí |  |  |
| `payload_json` | `TEXT` | Sí |  |  |
| `created_at` | `TEXT` | Sí |  |  |

Referencias externas: 0

## batch_consumptions — Producción

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `batch_id` | `TEXT` | Sí |  FK→batches.id |  |
| `ingredient_id` | `TEXT` | Sí |  FK→ingredients.id |  |
| `purchase_line_id` | `TEXT` | No |  FK→purchase_lines.id |  |
| `qty` | `REAL` | Sí |  | Cantidad numérica > 0 salvo movimientos |
| `unit` | `TEXT` | Sí |  |  |
| `actual_cost_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |

Referencias externas: 3

## batch_outputs — Producción

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `batch_id` | `TEXT` | Sí |  FK→batches.id |  |
| `sku_id` | `TEXT` | Sí |  FK→skus.id |  |
| `bottles` | `INTEGER` | Sí |  | Cantidad entera positiva; genera movimiento de inventario desde trigger |
| `packaging_cost_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |

Referencias externas: 2

## batches — Producción

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `batch_number` | `TEXT` | Sí |  |  |
| `variant_id` | `TEXT` | Sí |  FK→variants.id |  |
| `recipe_id` | `TEXT` | Sí |  FK→recipe_versions.id |  |
| `source` | `TEXT` | Sí |  |  |
| `produced_at` | `TEXT` | Sí |  |  |
| `refrigerated_at` | `TEXT` | No |  |  |
| `expected_ml` | `INTEGER` | Sí |  |  |
| `actual_ml` | `INTEGER` | Sí |  | Volumen REAL medido de un lote; limita el número de botellas terminadas |
| `status` | `TEXT` | Sí |  |  |
| `extra_cost_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `notes` | `TEXT` | Sí |  |  |
| `created_at` | `TEXT` | Sí |  |  |

Referencias externas: 2

## clients — Clientes

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `name` | `TEXT` | Sí |  |  |
| `phone` | `TEXT` | Sí |  | Obligatorio para clientes: exactamente 10 dígitos ASCII [0-9]{10}; sin guiones ni espacios |
| `email` | `TEXT` | No |  |  |
| `address` | `TEXT` | Sí |  |  |
| `notes` | `TEXT` | Sí |  |  |
| `created_at` | `TEXT` | Sí |  |  |
| `active` | `INTEGER` | Sí |  |  |

Referencias externas: 0

## deliveries — Inventario

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `invoice_id` | `TEXT` | Sí |  FK→invoices.id |  |
| `delivered_at` | `TEXT` | Sí |  |  |
| `notes` | `TEXT` | Sí |  |  |
| `idempotency_key` | `TEXT` | Sí |  | Obligatorio y único para prevenir duplicados de cobros/entregas al reintentar |

Referencias externas: 1

## delivery_lines — Inventario

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `delivery_id` | `TEXT` | Sí |  FK→deliveries.id |  |
| `invoice_line_id` | `TEXT` | Sí |  FK→invoice_lines.id |  |
| `batch_output_id` | `TEXT` | Sí |  FK→batch_outputs.id |  |
| `qty` | `INTEGER` | Sí |  | Cantidad numérica > 0 salvo movimientos |

Referencias externas: 3

## documents — Documentos

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `kind` | `TEXT` | Sí |  |  |
| `record_id` | `TEXT` | Sí |  |  |
| `filename` | `TEXT` | Sí |  |  |
| `format` | `TEXT` | Sí |  |  |
| `sha256` | `TEXT` | Sí |  |  |
| `created_at` | `TEXT` | Sí |  |  |

Referencias externas: 0

## families — Productos

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `name` | `TEXT` | Sí |  |  |
| `active` | `INTEGER` | Sí |  |  |

Referencias externas: 0

## ingredients — Fórmulas

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `name` | `TEXT` | Sí |  |  |
| `base_unit` | `TEXT` | Sí |  |  |
| `allergen` | `TEXT` | Sí |  |  |

Referencias externas: 0

## invoice_charges — Facturación

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `invoice_id` | `TEXT` | Sí |  FK→invoices.id |  |
| `pack_id` | `TEXT` | No |  FK→packaging_packs.id |  |
| `description` | `TEXT` | Sí |  |  |
| `qty` | `INTEGER` | Sí |  | Cantidad numérica > 0 salvo movimientos |
| `unit_price_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `unit_cost_snapshot_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `line_total_cents` | `INTEGER` | No |  | Calculado por SQLite: no editable. Columna SQL GENERATED, qty x unit_price_cents; no editable |

Referencias externas: 2

## invoice_lines — Facturación

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `invoice_id` | `TEXT` | Sí |  FK→invoices.id |  |
| `sku_id` | `TEXT` | Sí |  FK→skus.id |  |
| `description` | `TEXT` | Sí |  |  |
| `qty` | `INTEGER` | Sí |  | Cantidad numérica > 0 salvo movimientos |
| `unit_price_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `unit_cost_snapshot_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `line_total_cents` | `INTEGER` | No |  | Calculado por SQLite: no editable. Columna SQL GENERATED, qty x unit_price_cents; no editable |

Referencias externas: 2

## invoices — Facturación

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `number` | `TEXT` | Sí |  |  |
| `quote_id` | `TEXT` | No |  FK→quotes.id |  |
| `client_id` | `TEXT` | Sí |  FK→clients.id |  |
| `issued_at` | `TEXT` | Sí |  |  |
| `status` | `TEXT` | Sí |  |  |
| `notes` | `TEXT` | Sí |  |  |
| `discount_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `shipping_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |

Referencias externas: 2

## pack_lines — Empaques

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `pack_id` | `TEXT` | Sí |  FK→packaging_packs.id |  |
| `label` | `TEXT` | Sí |  |  |
| `quantity` | `REAL` | Sí |  | Cantidad numérica > 0 salvo movimientos |
| `unit_cost_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `scope` | `TEXT` | Sí |  |  |

Referencias externas: 1

## packaging_packs — Empaques

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `name` | `TEXT` | Sí |  |  |
| `description` | `TEXT` | Sí |  |  |
| `active` | `INTEGER` | Sí |  |  |

Referencias externas: 0

## payments — Cobros

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `invoice_id` | `TEXT` | Sí |  FK→invoices.id |  |
| `amount_cents` | `INTEGER` | Sí |  | Moneda almacenada como entero de centavos; UI acepta sólo 0-9 y punto con hasta 2 decimales |
| `method` | `TEXT` | Sí |  |  |
| `reference` | `TEXT` | Sí |  |  |
| `paid_at` | `TEXT` | Sí |  |  |
| `idempotency_key` | `TEXT` | Sí |  | Obligatorio y único para prevenir duplicados de cobros/entregas al reintentar |

Referencias externas: 1

## products — Productos

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `family_id` | `TEXT` | Sí |  FK→families.id |  |
| `name` | `TEXT` | Sí |  |  |
| `description` | `TEXT` | Sí |  |  |
| `active` | `INTEGER` | Sí |  |  |

Referencias externas: 1

## purchase_lines — Producción

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `purchase_id` | `TEXT` | Sí |  FK→purchases.id |  |
| `ingredient_id` | `TEXT` | Sí |  FK→ingredients.id |  |
| `purchased_qty` | `REAL` | Sí |  | Cantidad numérica > 0 salvo movimientos |
| `unit` | `TEXT` | Sí |  |  |
| `total_cost_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |

Referencias externas: 2

## purchases — Producción

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `purchased_at` | `TEXT` | Sí |  |  |
| `merchant` | `TEXT` | Sí |  |  |
| `receipt_ref` | `TEXT` | Sí |  |  |
| `notes` | `TEXT` | Sí |  |  |
| `created_at` | `TEXT` | Sí |  |  |

Referencias externas: 0

## quote_charges — Cotizaciones

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `quote_id` | `TEXT` | Sí |  FK→quotes.id |  |
| `pack_id` | `TEXT` | No |  FK→packaging_packs.id |  |
| `description` | `TEXT` | Sí |  |  |
| `qty` | `INTEGER` | Sí |  | Cantidad numérica > 0 salvo movimientos |
| `unit_price_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `unit_cost_snapshot_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `line_total_cents` | `INTEGER` | No |  | Calculado por SQLite: no editable. Columna SQL GENERATED, qty x unit_price_cents; no editable |

Referencias externas: 2

## quote_lines — Cotizaciones

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `quote_id` | `TEXT` | Sí |  FK→quotes.id |  |
| `sku_id` | `TEXT` | Sí |  FK→skus.id |  |
| `description` | `TEXT` | Sí |  |  |
| `qty` | `INTEGER` | Sí |  | Cantidad numérica > 0 salvo movimientos |
| `unit_price_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `unit_cost_snapshot_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `line_total_cents` | `INTEGER` | No |  | Calculado por SQLite: no editable. Columna SQL GENERATED, qty x unit_price_cents; no editable |

Referencias externas: 2

## quotes — Cotizaciones

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `number` | `TEXT` | Sí |  |  |
| `client_id` | `TEXT` | Sí |  FK→clients.id |  |
| `issued_at` | `TEXT` | Sí |  |  |
| `valid_until` | `TEXT` | No |  |  |
| `mode` | `TEXT` | Sí |  |  |
| `status` | `TEXT` | Sí |  |  |
| `notes` | `TEXT` | Sí |  |  |
| `discount_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `shipping_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |

Referencias externas: 1

## receipts — Cobros

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `number` | `TEXT` | Sí |  |  |
| `payment_id` | `TEXT` | Sí |  FK→payments.id |  |
| `created_at` | `TEXT` | Sí |  |  |
| `document_path` | `TEXT` | Sí |  |  |

Referencias externas: 1

## recipe_lines — Fórmulas

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `recipe_id` | `TEXT` | Sí |  FK→recipe_versions.id |  |
| `ingredient_id` | `TEXT` | Sí |  FK→ingredients.id |  |
| `quantity` | `REAL` | Sí |  | Cantidad numérica > 0 salvo movimientos |
| `unit` | `TEXT` | Sí |  |  |
| `estimated_cost_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |

Referencias externas: 2

## recipe_versions — Fórmulas

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `variant_id` | `TEXT` | Sí |  FK→variants.id |  |
| `version_no` | `INTEGER` | Sí |  |  |
| `title` | `TEXT` | Sí |  |  |
| `yield_ml` | `INTEGER` | Sí |  | Rendimiento teórico por fórmula (puede diferir del rendimiento real) |
| `process_type` | `TEXT` | Sí |  |  |
| `instructions` | `TEXT` | Sí |  |  |
| `status` | `TEXT` | Sí |  |  |
| `created_at` | `TEXT` | Sí |  |  |

Referencias externas: 1

## settings — Configuración

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `key` | `TEXT` | Sí | PK |  |
| `value` | `TEXT` | Sí |  |  |
| `updated_at` | `TEXT` | Sí |  |  |

Referencias externas: 0

## skus — Productos

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `variant_id` | `TEXT` | Sí |  FK→variants.id |  |
| `size_ml` | `INTEGER` | Sí |  |  |
| `packaging_id` | `TEXT` | No |  FK→packaging_packs.id |  |
| `title` | `TEXT` | Sí |  |  |
| `bottle_cost_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `label_cost_cents` | `INTEGER` | Sí |  | Entero de centavos (no símbolo ni flotantes) |
| `price_cents` | `INTEGER` | Sí |  | Moneda almacenada como entero de centavos; los precios históricos se copian en líneas al cotizar/facturar |
| `active` | `INTEGER` | Sí |  |  |

Referencias externas: 2

## stock_movements — Inventario

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `batch_output_id` | `TEXT` | Sí |  FK→batch_outputs.id |  |
| `kind` | `TEXT` | Sí |  |  |
| `delta_bottles` | `INTEGER` | Sí |  | Movimiento de stock (entrega negativa); validación impide saldo negativo |
| `delivery_line_id` | `TEXT` | No |  FK→delivery_lines.id |  |
| `reference` | `TEXT` | Sí |  |  |
| `created_at` | `TEXT` | Sí |  |  |

Referencias externas: 2

## sync_outbox — Sincronización

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `entity` | `TEXT` | Sí |  |  |
| `entity_id` | `TEXT` | Sí |  |  |
| `op` | `TEXT` | Sí |  |  |
| `payload_json` | `TEXT` | Sí |  |  |
| `created_at` | `TEXT` | Sí |  |  |
| `synced_at` | `TEXT` | No |  | Marca futura de sincronización; proceso cloud no implementado |
| `attempts` | `INTEGER` | Sí |  |  |

Referencias externas: 0

## sync_state — Sincronización

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `key` | `TEXT` | Sí | PK |  |
| `value` | `TEXT` | Sí |  |  |
| `updated_at` | `TEXT` | Sí |  |  |

Referencias externas: 0

## variants — Productos

| Campo | Tipo | Obligatorio | Clave / relación | Regla especial |
|---|---|---|---|---|
| `id` | `TEXT` | Sí | PK |  |
| `product_id` | `TEXT` | Sí |  FK→products.id |  |
| `name` | `TEXT` | Sí |  |  |
| `alcohol` | `INTEGER` | Sí |  |  |
| `active` | `INTEGER` | Sí |  |  |

Referencias externas: 1

# Vistas calculadas

`v_stock`: producido y disponible por lote/SKU, a partir de movimientos firmados.
`v_invoice_balances`: total facturado, suma de cobros y saldo pendiente (incluye packs y cargos).
`v_batch_costs`: costo consumido, envases y otros gastos realmente asignados al lote.

# Reglas de validación cruzada

- No se permite envasar un SKU perteneciente a otra variante ni exceder `batches.actual_ml`.
- No se permite sacar más inventario del disponible.
- No se permite entregar artículos distintos al SKU facturado ni cantidades superiores a lo facturado.
- No se permite pagar más de lo facturado ni pagar una factura anulada.
- `idempotency_key` único para cobros y entregas; facturar dos veces la misma cotización bloqueado.
- Estado de producto y lotes gobierna disponibilidad.

# Alcance

El archivo SQL no es todavía el esquema de producción Android. Es la base relacional de validación, preparada para posterior migración/replicación.