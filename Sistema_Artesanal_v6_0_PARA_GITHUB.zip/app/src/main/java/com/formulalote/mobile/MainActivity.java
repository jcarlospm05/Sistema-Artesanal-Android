package com.formulalote.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.content.ContentValues;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.webkit.WebResourceRequest;
import android.webkit.JavascriptInterface;
import android.graphics.Color;
import android.view.WindowManager;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class MainActivity extends Activity {
    private WebView web;
    private DatabaseBridge store;
    private byte[] pendingSave;
    private String pendingMime;
    private static final int SAVE_FILE=101, OPEN_BACKUP=102;
    @Override public void onCreate(Bundle b){super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(21,61,49));getWindow().setNavigationBarColor(Color.rgb(21,61,49));
        store=new DatabaseBridge(this);
        web=new WebView(this);setContentView(web);
        web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setAllowContentAccess(false);
        web.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        WebView.setWebContentsDebuggingEnabled(false);
        web.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){return !r.getUrl().toString().startsWith("file:///android_asset/");}
        });
        web.addJavascriptInterface(store,"SQLiteBridge");
        web.addJavascriptInterface(new FileBridge(),"AndroidFiles");
        web.loadUrl("file:///android_asset/index.html");
    }
    private void signal(String js){runOnUiThread(()->web.evaluateJavascript(js,null));}
    private void toast(String msg){signal("window.nativeNotice?.("+JSONObject.quote(msg)+")");}
    public final class FileBridge {
        @JavascriptInterface public void saveBase64(String filename,String mime,String base64){
            try{
                byte[] bytes=Base64.getDecoder().decode(base64.replaceFirst("^data:[^,]+,",""));
                saveFile(filename,mime,bytes);
            }catch(Exception e){toast(e.getMessage());}
        }
        @JavascriptInterface public void saveJson(String filename,String json){saveFile(filename,"application/json",json.getBytes(StandardCharsets.UTF_8));}
        @JavascriptInterface public void exportSQLite(){
            try{File f=store.snapshotBackup();try(InputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){
                byte[] b=new byte[16384];int n;while((n=in.read(b))!=-1)out.write(b,0,n);saveFile("Sistema_Artesanal_respaldo.sqlite","application/vnd.sqlite3",out.toByteArray());
            }finally{f.delete();}}catch(Exception e){toast("No se pudo exportar: "+e.getMessage());}
        }
        @JavascriptInterface public void importSQLite(){runOnUiThread(()->{
            Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN_BACKUP);
        });}
        private Uri storePng(String filename,byte[] bytes) throws Exception {
            String folder=filename.startsWith("COT-")?"Cotizaciones":filename.startsWith("FAC-")?"Facturas":filename.startsWith("REC-")?"Recibos":"Otros";
            ContentValues cv=new ContentValues();cv.put(MediaStore.Images.Media.DISPLAY_NAME,filename);
            cv.put(MediaStore.Images.Media.MIME_TYPE,"image/png");
            cv.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Sistema Artesanal/"+folder);
            Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);
            if(uri==null)throw new IOException("No se creó imagen");
            try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("No se abrió el destino");out.write(bytes);}
            return uri;
        }
        @JavascriptInterface public void savePng(String filename,String base64){
            try {byte[] bytes=Base64.getDecoder().decode(base64.replaceFirst("^data:[^,]+,",""));
                runOnUiThread(()->{try{storePng(filename,bytes);toast("PNG guardado en Imágenes / Sistema Artesanal");}catch(Exception e){toast(e.getMessage());}});
            }catch(Exception e){toast(e.getMessage());}
        }
        @JavascriptInterface public void printHtml(String title,String html){
            runOnUiThread(()->{
                WebView printer=new WebView(MainActivity.this);
                printer.getSettings().setJavaScriptEnabled(false);
                printer.setWebViewClient(new WebViewClient(){
                    @Override public void onPageFinished(WebView v,String url){
                        PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                        pm.print(title,printer.createPrintDocumentAdapter(title),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build());
                    }
                });
                printer.loadDataWithBaseURL(null,"<!doctype html><html lang='es'><meta charset='utf-8'><style>body{font:14px Arial;padding:20px}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid #ddd;padding:8px;text-align:left}</style><body>"+html+"</body></html>","text/html","utf-8",null);
            });
        }
        @JavascriptInterface public void sharePng(String filename,String base64){
            try {byte[] bytes=Base64.getDecoder().decode(base64.replaceFirst("^data:[^,]+,",""));runOnUiThread(()->{
                try{
                    Uri uri=storePng(filename,bytes);
                    Intent share=new Intent(Intent.ACTION_SEND);share.setType("image/png");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share,"Compartir documento"));
                }catch(Exception e){toast(e.getMessage());}
            });}catch(Exception e){toast(e.getMessage());}
        }
    }
    private void saveFile(String name,String mime,byte[] bytes){runOnUiThread(()->{
        pendingSave=bytes;pendingMime=mime;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType(mime);i.putExtra(Intent.EXTRA_TITLE,name);
        startActivityForResult(i,SAVE_FILE);
    });}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();
        if(request==SAVE_FILE){try(OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new IOException("Sin acceso al destino");out.write(pendingSave);toast("Archivo guardado");}catch(Exception e){toast("Error guardando: "+e.getMessage());}finally{pendingSave=null;}}
        if(request==OPEN_BACKUP){try(InputStream in=getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("Archivo inaccesible");File tmp=File.createTempFile("import_",".sqlite",getCacheDir());try(OutputStream out=new FileOutputStream(tmp)){
                byte[] b=new byte[16384];int n;long total=0;while((n=in.read(b))!=-1){total+=n;if(total>100_000_000)throw new IOException("Respaldo demasiado grande");out.write(b,0,n);}}
            new AlertDialog.Builder(this).setTitle("¿Restaurar base de datos?")
                .setMessage("Sustituirá los datos actuales de este celular. Antes se guardará una copia local de seguridad. Asegúrate de tener otra copia externa.")
                .setNegativeButton("Cancelar",(a,b)->tmp.delete())
                .setPositiveButton("Restaurar",(a,b)->{try{store.restore(tmp);web.reload();toast("Base restaurada");}catch(Exception e){toast("Restauración cancelada: "+e.getMessage());}finally{tmp.delete();}}).show();
        }catch(Exception e){toast("No se abrió respaldo: "+e.getMessage());}}
    }
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
