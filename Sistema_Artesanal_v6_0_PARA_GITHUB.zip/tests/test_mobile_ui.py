"""Browser-only mobile UI integration against temporary SQLite SQL bridge, NOT an Android APK test."""
import tempfile, shutil, sqlite3, json, threading, os, socket, pathlib, http.server
from playwright.sync_api import sync_playwright
ROOT=pathlib.Path(__file__).resolve().parents[1]
ASSETS=ROOT/'app/src/main/assets'
TMP=pathlib.Path(tempfile.mkdtemp(prefix='art-ui-'))
DB=TMP/'test.sqlite';shutil.copyfile(ASSETS/'artesanal.sqlite',DB)
class H(http.server.SimpleHTTPRequestHandler):
    def __init__(self,*a,**kw):super().__init__(*a,directory=str(ASSETS),**kw)
    def log_message(self,*a):pass
    def do_POST(self):
        if self.path!='/sql':self.send_error(404);return
        req=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        conn=sqlite3.connect(DB);conn.row_factory=sqlite3.Row;conn.execute('PRAGMA foreign_keys=ON');out=[]
        try:
            if req.get('tx'):conn.execute('BEGIN IMMEDIATE')
            for op in req.get('steps',[]):
                cur=conn.execute(op['sql'],op.get('params',[]));mode=op.get('mode','run')
                if mode=='all':out.append([dict(row) for row in cur.fetchall()])
                elif mode=='one':
                    row=cur.fetchone();out.append(dict(row) if row else None)
                else:out.append(None)
            conn.commit();body={'results':out}
        except Exception as e:conn.rollback();body={'error':str(e)}
        finally:conn.close()
        response=json.dumps(body,ensure_ascii=False).encode()
        self.send_response(200);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(response)));self.end_headers();self.wfile.write(response)
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),H)
threading.Thread(target=server.serve_forever,daemon=True).start()
print('Testing UI from',server.server_address)
try:
 with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':393,'height':852},device_scale_factor=1,is_mobile=True,has_touch=True)
    page.add_init_script('''
      window.SQLiteBridge={
        newId:()=>crypto.randomUUID(),
        execute:(payload)=>{let xhr=new XMLHttpRequest();xhr.open('POST','/sql',false);xhr.setRequestHeader('Content-Type','application/json');xhr.send(payload);return xhr.responseText;}
      };
      window.AndroidFiles={saveJson(){},exportSQLite(){},importSQLite(){},savePng(){},sharePng(){},printHtml(){}};
    ''')
    errors=[];page.on('pageerror',lambda err:errors.append(str(err)))
    page.goto(f'http://127.0.0.1:{server.server_port}/index.html',wait_until='domcontentloaded')
    page.locator('#enter').click()
    page.wait_for_selector('.metric',timeout=15000)
    assert 'Dashboard' in page.locator('#page-name').inner_text()
    assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2'), 'Body overflows horizontally'
    pathlib.Path('/mnt/data').joinpath('Sistema_Artesanal_Android_v6_0_dashboard.png').write_bytes(page.screenshot(full_page=True))
    page.locator('[data-page=production]').first.click()
    page.wait_for_selector('#production-form')
    assert page.evaluate('document.documentElement.scrollWidth<=window.innerWidth+2'), 'Production page overflows horizontally'
    pathlib.Path('/mnt/data').joinpath('Sistema_Artesanal_Android_v6_0_produccion.png').write_bytes(page.screenshot(full_page=True))
    page.locator('[data-page=clients]').first.click()
    page.wait_for_selector('#client-form')
    page.locator('#client-form input[name=name]').fill('Cliente Prueba Android')
    page.locator('#client-form input[name=phone]').fill('8095551234')
    page.locator('#client-form button[type=submit]').click()
    page.wait_for_timeout(350)
    assert 'Cliente Prueba Android' in page.locator('#view').inner_text()
    print('UI: Dashboard, production layout, client submission PASS')
    assert not errors, errors
    print('JavaScript runtime errors:',errors)
    browser.close()
finally:
 server.shutdown();shutil.rmtree(TMP,ignore_errors=True)
